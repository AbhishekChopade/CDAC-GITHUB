package customexception;

public class QueueHandlingException extends Exception {
	public QueueHandlingException (String mesg) {
		super(mesg);
	}
}
