package exceptions;

public class QueueHandlingException extends Exception {
	public QueueHandlingException(String mesg){
		super(mesg);
	}
}
