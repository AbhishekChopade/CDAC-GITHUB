package com.app.exception;

public class LinkedListHandlingException extends Exception {
	public LinkedListHandlingException(String mesg) {
		super(mesg);
	}
}
