package exceptions;

public class LinkedListHandlingException extends Exception {
	public LinkedListHandlingException(String mesg) {
		super(mesg);
	}
}
