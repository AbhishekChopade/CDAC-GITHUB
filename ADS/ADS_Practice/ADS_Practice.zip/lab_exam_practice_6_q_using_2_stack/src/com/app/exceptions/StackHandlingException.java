package com.app.exceptions;

public class StackHandlingException extends Exception {
	public StackHandlingException(String mesg) {
		super (mesg);
	}
}
