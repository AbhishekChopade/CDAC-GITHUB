package com.app.pets;

public enum Category {
	CAT, DOG, RABBIT, FISH;
}
