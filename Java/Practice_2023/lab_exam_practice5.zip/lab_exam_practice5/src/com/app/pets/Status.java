package com.app.pets;

public enum Status {
	PLACED, IN_PROCESS, COMPLETED
}
