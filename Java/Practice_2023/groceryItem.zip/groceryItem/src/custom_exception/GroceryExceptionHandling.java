package custom_exception;

public class GroceryExceptionHandling extends Exception {
	public GroceryExceptionHandling(String mesg) {
		super(mesg);
	}
}
