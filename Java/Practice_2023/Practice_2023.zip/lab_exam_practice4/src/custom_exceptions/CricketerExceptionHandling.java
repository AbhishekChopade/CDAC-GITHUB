package custom_exceptions;

public class CricketerExceptionHandling extends Exception {
	public CricketerExceptionHandling(String mesg) {
		super(mesg);
	}
}
