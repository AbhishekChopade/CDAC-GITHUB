package custom_exception;

public class TaskHandlingException extends Exception {
	public TaskHandlingException(String mesg) {
		super(mesg);
	}
}
