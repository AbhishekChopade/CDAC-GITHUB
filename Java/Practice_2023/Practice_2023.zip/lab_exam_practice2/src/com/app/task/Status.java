package com.app.task;

public enum Status {

	PENDING, INPROGRESS, COMPLETED
}
