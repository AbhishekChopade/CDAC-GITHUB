package custom_exceptions;

public class PenHandlingExceptions extends Exception{
	public PenHandlingExceptions(String mesg) {
		super(mesg);
	}
}
