package com.app.core;

public enum Brand {
	CELLO, PARKER, REYNOLDS;
	
	public String toString() {
		return name();
	}
}
