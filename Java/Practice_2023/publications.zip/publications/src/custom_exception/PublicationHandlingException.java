package custom_exception;

public class PublicationHandlingException extends Exception {
	public PublicationHandlingException(String mesg) {
		super(mesg);
	}
}
