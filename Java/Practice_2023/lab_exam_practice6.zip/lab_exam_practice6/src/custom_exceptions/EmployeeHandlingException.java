package custom_exceptions;

public class EmployeeHandlingException extends Exception {
	public EmployeeHandlingException(String mesg) {
		super(mesg);
	}
}
