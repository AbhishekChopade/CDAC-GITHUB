package com.app.core;

public interface Stack {
	int STACK_SIZE = 2;
	void push(Customer c);
	Customer pop();
	
}
